PAL LAICH OS 17 — harmless Android prank app
================================================

This is a joke app. It does not access files, contacts, network, camera,
microphone, or device administration. It does not lock the phone or persist
in the background. The "scan" is only a visual animation.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK will appear under app/build/outputs/apk/debug/.

Package: com.qcold.pallaich
Minimum Android: 6.0 (API 23)
Target SDK: 35
