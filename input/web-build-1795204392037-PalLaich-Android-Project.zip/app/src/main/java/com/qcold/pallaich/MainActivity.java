package com.qcold.pallaich;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private TextView counter;
    private int doubles = 2;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.BLACK);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFFD54F));
        return b;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        );

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));
        root.setBackgroundColor(0xFF180000);

        TextView stamp = text("⚠  СИСТЕМНОЕ УВЕДОМЛЕНИЕ  ⚠", 14, 0xFFFFD54F);
        root.addView(stamp);

        TextView title = text("ПАЛ ЛАИЧ
ОБНАРУЖЕН", 34, Color.WHITE);
        title.setPadding(dp(8), dp(24), dp(8), dp(12));
        root.addView(title);

        TextView sub = text("Ваш Android временно переведён
в режим государственного юмора.", 17, 0xFFFFB3B3);
        root.addView(sub);

        status = text("Проверка двойников: завершена", 15, 0xFFFFFFFF);
        status.setPadding(0, dp(24), 0, dp(4));
        root.addView(status);

        counter = text("ДВОЙНИКОВ ОБНАРУЖЕНО: 2", 16, 0xFFFFD54F);
        root.addView(counter);

        Button call = button("📞  Вызвать президента");
        root.addView(call, matchWrap());
        call.setOnClickListener(v -> {
            status.setText("Соединение установлено…
Абонент занят на совещании.");
            Toast.makeText(this, "Пал Лаич пока не отвечает", Toast.LENGTH_SHORT).show();
        });

        Button scan = button("🔎  Проверить систему");
        root.addView(scan, matchWrap());
        scan.setOnClickListener(v -> runFakeScan());

        Button doublesButton = button("👥  Найти ещё одного двойника");
        root.addView(doublesButton, matchWrap());
        doublesButton.setOnClickListener(v -> {
            doubles++;
            counter.setText("ДВОЙНИКОВ ОБНАРУЖЕНО: " + doubles);
            status.setText("Новый двойник найден.
Уровень мемности повышен.");
        });

        Button exit = button("✖  Освободить телефон");
        root.addView(exit, matchWrap());
        exit.setOnClickListener(v -> {
            status.setText("Телефон свободен. Это был розыгрыш :)");
            Toast.makeText(this, "Пал Лаич покинул систему", Toast.LENGTH_LONG).show();
            handler.postDelayed(this::finish, 1200);
        });

        TextView footer = text("PAL LAICH OS 17  •  ПАРОДИЯ\nНичего не блокирует и не меняет в телефоне.", 11, 0xFFBCAAAA);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);

        setContentView(root);
        root.setAlpha(0f);
        root.animate().alpha(1f).setDuration(700).start();
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(7);
        return p;
    }

    private void runFakeScan() {
        status.setText("Сканирование… 0%");
        final int[] progress = {0};
        Runnable tick = new Runnable() {
            @Override public void run() {
                progress[0] += 20;
                if (progress[0] >= 100) {
                    status.setText("Угроза найдена: ПАЛ ЛАИЧ\nРекомендация: выпить чаю.");
                    Toast.makeText(MainActivity.this, "Сканирование завершено. Угроз: 0 настоящих.", Toast.LENGTH_LONG).show();
                } else {
                    status.setText("Сканирование… " + progress[0] + "%");
                    handler.postDelayed(this, 250);
                }
            }
        };
        handler.postDelayed(tick, 250);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
